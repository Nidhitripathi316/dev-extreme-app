import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { DxDataGridModule,DxTemplateModule, DxSelectBoxModule, DxCheckBoxModule,DxListModule  } from 'devextreme-angular';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PocArrayComponent } from './poc-array/poc-array.component';
import { PocArrayService } from './poc-array.service';
import { PocCustomComponent } from './poc-custom/poc-custom.component';
import {  HttpClientModule } from '@angular/common/http';
import { PocDynamicRenderComponent } from './poc-dynamic-render/poc-dynamic-render.component';

@NgModule({
  declarations: [
    AppComponent,
    PocArrayComponent,
    PocCustomComponent,
    PocDynamicRenderComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    DxDataGridModule,
    DxTemplateModule, 
    DxSelectBoxModule,
     DxCheckBoxModule,
     DxListModule,
     HttpClientModule
  ],
  providers: [PocArrayService],
  bootstrap: [AppComponent]
})
export class AppModule { }
